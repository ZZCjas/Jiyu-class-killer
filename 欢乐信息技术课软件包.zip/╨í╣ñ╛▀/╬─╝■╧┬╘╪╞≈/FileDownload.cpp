#include <cstdio>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <ctime> 
#include <windows.h>
#include <conio.h>
#include <urlmon.h>
using namespace std;
string ar1,ar2;
BOOL FileExistsStatus(const CHAR* path)
{
	DWORD dwAttribute=GetFileAttributes((LPCSTR)path);
	if(dwAttribute==0XFFFFFFFF) 
	{
		return false; 
	}
	else 
	{
		return true;
	}
}
BOOL DownloadFiles(const CHAR* url,const CHAR* downloadPath)
{
	if(URLDownloadToFile(NULL,(LPCSTR)url,(LPCSTR)downloadPath,0,0)==S_OK&&FileExistsStatus(downloadPath)) 
	{
		return true;
	}
	else
	{
		return false;
	}
}
clock_t start,eend;
int ttt;
string gett()
{
	time_t now=time(0);
	string dt=ctime(&now);
	dt[dt.size()-1]=' ';
	return dt;
}
int main(int argc,char* argv[])
{
	if(argc==4)
	{
		ar1=argv[1],ar2=argv[2];
		ttt=atoi(argv[3]); 
	}
	else
	{
		cout<<"Please input the URL which you want to download:";	
		cin>>ar1;
		cout<<"Please input the path where you want to save the URL:";
		cin>>ar2; 
		cout<<"Please input the number of attempts:";
		cin>>ttt; 
	}
	cout<<"Number of attempts:"<<ttt<<endl;
	cout<<"Downloading starts at "<<gett()<<endl;
	start=clock();
	for(register int i=1;i<=ttt;i++)
	{
		cout<<"Downloading. . .\n";
		cout<<"Status:";
		if(DownloadFiles(ar1.c_str(),ar2.c_str()))
		{
			eend=clock();
			cout<<"Succeed!\nTime:";
			cout.precision(3);
			cout<<fixed<<(double)(eend-start)/1000<<"s\n";
			cout<<"Downloading finishes at "<<gett()<<endl;
			cout<<"Press any key to continue. . .";
			getch();
			return 0;
		}
		else
		{
			cout<<"Fail!\n";
		}
	}
	cout<<"Downloading fails at "<<gett()<<endl;
	cout<<"Press any key to continue. . .";
	getch(); 
}
